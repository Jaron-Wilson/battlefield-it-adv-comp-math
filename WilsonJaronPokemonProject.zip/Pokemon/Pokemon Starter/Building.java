import greenfoot.*;

public class Building extends Actor
{
 
}
