import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Gator here.
 * 
 * @author Jaron Wilson 
 * @version 11/1/2022
 */
public class Gator extends SmoothMover
{
    
    public void act() 
    {
        // Add your action code here.
    }    
}
