
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ShowControls here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ShowControls extends Actor
{
    private Boolean enabled = true;
    /**
     * Act - do whatever the ShowControls wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        showControls(!enabled);
        if(Greenfoot.isKeyDown("=")){
            showControls(enabled);
        }
    }    

    public boolean showControls(Boolean shown){
        Boolean isTrue = false;
        if(shown == true){
            getWorld().showText(
                " ",120,25);
            getWorld().showText(
                "Controls (1 & 2) Player 1", 120, 20);
            getWorld().showText(
                "Controls (<- & ->) Player 2", 120, 40);
            getWorld().showText(
                "w,s,x", 120, 60);
            getWorld().showText(
                "e,d,c", 120, 80);
            isTrue = true;
        }else if (shown == false){
            getWorld().showText(
                "Hold = to see controls",
                120, 25);
            getWorld().showText(
                " ", 120, 20);
            getWorld().showText(
                " ", 120, 40);
            getWorld().showText(
                " ", 120, 60);
            getWorld().showText(
                " ", 120, 80);
            isTrue = false;
        }
        return isTrue;
    }
}
