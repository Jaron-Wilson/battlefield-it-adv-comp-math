import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Spawns Objects onto screen and adds a Snitch at a random spot and
 * and only works .001 amount of the time act() is called.
 * 
 * @author Jaron Wilson 
 * @version 10-1-22
 */
public class Field extends World
{
    //Make a music delay
    private int timeCount=0;
    public Field()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 530, 1);
        prepare();
        act();
        
    }

    private void playMusic(){
        //Greenfoot.playSound("boxelReboundMusic.wav");
    }

    public void act() {
        if( Math.random() <  0.001 )
        {
            Snitch snitch = new Snitch(); 
            addObject(snitch, (int)(Math.random() * getWidth()),
                (int)(Math.random() * getHeight()));
        }
    }

    public void tick(){
        if(timeCount <= 0) {
            // then set the timeCount to 54 second cool down
            timeCount = 54;
            playMusic();
        }else {
            /* else if its bigger than or not equal to 0
            subtract 1 everytime */
            timeCount--;
        }
    }

    private void prepare()
    {
        ScoreBoard scoreB = new ScoreBoard();
        addObject(scoreB, 506,31);
        ShowControls showC = new ShowControls();
        addObject(showC, 38,26);
        Seeker seeker = new Seeker();
        addObject(seeker,461,277);
        Beater beater = new Beater();
        addObject(beater,409,247);
        Beater beater2 = new Beater();
        addObject(beater2,401,324);
        Chaser chase = new Chaser();
        addObject(chase,594,253);
        Chaser chasery = new Chaser();
        addObject(chasery,590,320);
        GoalHoop good = new GoalHoop();
        addObject(good,936,131);
        GoalHoop2 bad = new GoalHoop2();
        addObject(bad,60,114);
        SeekerGood seekerGood = new SeekerGood();
        addObject(seekerGood,542,286);
    }
}
