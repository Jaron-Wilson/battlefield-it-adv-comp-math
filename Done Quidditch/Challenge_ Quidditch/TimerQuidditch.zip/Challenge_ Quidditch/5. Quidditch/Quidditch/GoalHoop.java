import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GoalHoop here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GoalHoop extends Actor
{
    /**
     * Act - do whatever the GoalHoop wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        checkTouching();
    }    
    private void checkTouching(){
        if (isTouching(Quaffle.class)){
            Greenfoot.playSound("chime.wav");
            removeTouching(Quaffle.class);
        }
    }
}
