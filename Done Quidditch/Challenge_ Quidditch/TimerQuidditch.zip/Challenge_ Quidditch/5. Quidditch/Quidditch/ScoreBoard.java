import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Count up the score and time played.
 * 
 * @author Jaron Wilson 
 * @version 10-1-22
 */
public class ScoreBoard extends Actor
{
    // Count up score variable.
    private int scoreTeam1;
    private int scoreTeam2;
    // Count up the time variable.
    private int millisElapsed = 0;
    private long lastTime = 0;

    public void act() {
        long time = System.currentTimeMillis();
        if(lastTime != 0) {
            long diff = time - lastTime;
            millisElapsed += diff;
        }
        lastTime = time;

        update();
    }

    public void update() {
        // Calculate minutes & seconds elapsed
        int secs = (millisElapsed / 1000) % 60;
        int mins = millisElapsed / 60000;
        // Convert these into text
        //%02d adds 2 -> 0 -> 00 to the end of the number
        String secsText = String.format("%02d", secs);
        // Minutes can stay as a whole number
        String minsText = "" + mins;
        String text = minsText + ":" + secsText;
        //Add the image to the world.
        getWorld().showText(text, getX(), getY());
        Field field = new Field();
        field.tick();
    }

    // Getter ScoreTeam1
    public int getScore1() {
        return scoreTeam1;
    }
    // Setter ScoreTeam1
    public void setScoreTeam1(int newScoreTeam1) {
        this.scoreTeam1 = newScoreTeam1;
    }
    // Getter ScoreTeam2
    public int getScore2() {
        return scoreTeam2;
    }
    // Setter ScoreTeam2
    public void setScoreTeam2(int newScoreTeam2) {
        this.scoreTeam2 = newScoreTeam2;
    }
}
