import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SeekerBad here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SeekerBad extends Actor
{
    /**
     * Act - do whatever the SeekerBad wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        move(-10);
        if(Greenfoot.isKeyDown("1")){
            turn(-5);
        }
        if(Greenfoot.isKeyDown("2")){
            turn(5);
        }
        if(isTouching(Snitch.class)){
            Greenfoot.playSound("applause.wav");
            removeTouching(Snitch.class);
        }
        if(isTouching(Bludger.class)){
            setLocation(getX(), 530);
            Greenfoot.playSound("thud.wav");
        }
    }    
}
