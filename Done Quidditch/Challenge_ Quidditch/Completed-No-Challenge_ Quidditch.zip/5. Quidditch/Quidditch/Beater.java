import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Beater here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Beater extends Actor
{
    /**
     * Act - do whatever the Beater wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // The Beaters turn randomly every act a small
        // amount randomly from 0 to 10 degrees. 
        turn((int) (Math.random() * 11)+0);
         if(Greenfoot.isKeyDown("W")){
            setLocation(getX(), getY() -5);
        }
        if(Greenfoot.isKeyDown("S")){
            setLocation(getX(), getY() +5);
        }
        if(Greenfoot.isKeyDown("x")){
            Bludger bludger = new Bludger();
            bludger.setRotation(getRotation());
            getWorld().addObject(bludger, getX() + 15, getY() + 10); 
        }
        //When a Beater hits a Quaffle,
        //it removes the Quaffle from the screen (think defense). 
        if (isTouching(Quaffle.class)) {
            removeTouching(Quaffle.class);
        }
    }    
}
