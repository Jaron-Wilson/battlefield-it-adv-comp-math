import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Chaser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Chaser extends Actor
{
    /**
     * Act - do whatever the Chaser wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        turn((int) (Math.random() * 31)-15);
         if(Greenfoot.isKeyDown("E")){
            setLocation(getX(), getY() -5);
        }
        if(Greenfoot.isKeyDown("D")){
            setLocation(getX(), getY() +5);
        }
        if(Greenfoot.isKeyDown("c")){
            Quaffle quaffle = new Quaffle();
            quaffle.setRotation(getRotation());
            getWorld().addObject(quaffle, getX() + 15, getY() + 10); 
        }
        if(isTouching(Bludger.class)){
            removeTouching(Bludger.class);
            // SIze of board:
            // super(1000, 530, 1);
            setLocation(
            (int) (Math.random() * 471) + 530,
            (int) (Math.random() * 471) + 530
            );
        }
    }    
}
