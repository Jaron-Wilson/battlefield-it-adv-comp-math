import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Field here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Field extends World
{

    /**
     * Constructor for objects of class Field.
     * 
     */
    public Field()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 530, 1);
        prepare();
        act();
    }
    public void act() {
        if( Math.random() <  0.001 )
        {
            Snitch snitch = new Snitch(); 
            addObject(snitch, (int)(Math.random() * getWidth()),
            (int)(Math.random() * getHeight()));
        }
    }

    private void prepare()
    {
        Seeker seeker = new Seeker();
        addObject(seeker,501,289);
        Beater beater = new Beater();
        addObject(beater,409,247);
        Beater beater2 = new Beater();
        addObject(beater2,401,324);
        Chaser chase = new Chaser();
        addObject(chase,594,253);
        Chaser chasery = new Chaser();
        addObject(chasery,590,320);
    }
}
