import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GoalHoop here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GoalHoop extends Actor
{
    private ScoreBoard scoreBoard = null;
    public GoalHoop(ScoreBoard score){
        this.scoreBoard = score;
    }
    /**
     * Act - do whatever the GoalHoop wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        checkTouching();
    }    
    private void checkTouching(){
        if (isTouching(Quaffle.class)){
            Greenfoot.playSound("chime.wav");
            addScore(10);
            removeTouching(Quaffle.class);
        }
    }
    private int addScore(int scoreToAdd){
        return scoreBoard.getAndIncrementScore1(scoreToAdd);
    }
}
