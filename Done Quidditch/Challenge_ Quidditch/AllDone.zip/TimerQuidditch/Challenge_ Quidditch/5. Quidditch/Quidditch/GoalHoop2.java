import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GoalHoop2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GoalHoop2 extends Actor
{
    private ScoreBoard scoreBoard = null;
    public GoalHoop2(ScoreBoard score){
        this.scoreBoard = score;
    }
    /**
     * Act - do whatever the GoalHoop2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        checkTouching();
    }    
    private void checkTouching(){
        if (isTouching(Quaffle.class)){
            Greenfoot.playSound("badgoal.wav");
            addScore(10);
            removeTouching(Quaffle.class);
        }
    }
    private int addScore(int scoreToAdd){
        return scoreBoard.getAndIncrementScore2(scoreToAdd);
    }
}
