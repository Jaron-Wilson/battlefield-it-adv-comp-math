import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Quaffle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Quaffle extends Actor
{
    /**
     * Act - do whatever the Quaffle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        move(10);
        //-10 to 10
        turn((int) (Math.random()* 21) +- 10);
         if(isAtEdge()){
            getWorld().removeObject(this);
        }
    }    
}
