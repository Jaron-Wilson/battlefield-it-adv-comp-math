import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SeekerBad here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SeekerGood extends Actor
{
    private ScoreBoard scoreBoard = null;
    public SeekerGood(ScoreBoard score){
        this.scoreBoard = score;
    }

    /**
     * Act - do whatever the SeekerBad wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        move(-5);
        if(Greenfoot.isKeyDown("1")){
            turn(-5);
        }
        if(Greenfoot.isKeyDown("2")){
            turn(5);
        }
        if(isTouching(Snitch.class)){
            Greenfoot.playSound("applause.wav");
            addScore(100);
            removeTouching(Snitch.class);
        }
        if(isTouching(Bludger.class)){
            setLocation(getX(), 530);
            Greenfoot.playSound("thud.wav");
        }
    }    

    private int addScore(int scoreToAdd){
        return scoreBoard.getAndIncrementScore1(scoreToAdd);
    }
}
