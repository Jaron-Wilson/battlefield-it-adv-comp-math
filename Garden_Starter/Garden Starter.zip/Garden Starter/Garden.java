import greenfoot.*;

public class Garden extends World
{
    public Garden()
    {    
        super(1000, 800, 1); 
    }
   
}
