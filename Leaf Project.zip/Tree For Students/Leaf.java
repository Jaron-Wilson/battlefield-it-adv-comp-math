import greenfoot.*;

public class Leaf extends Actor
{
    /*  Fields Go Here */
    

    
    
    /*  This is a Constructor */
    public Leaf()
    {
        
    }

    public void act() 
    {
        
    }    

/*
    public static int getNumLeaves()
    {
        return numLeaves;
    }
    
    public static void reset()
    {
        numLeaves = 0;
    }
*/
}
