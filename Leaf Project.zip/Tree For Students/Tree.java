import greenfoot.*;

public class Tree extends World
{

    public Tree()
    {    
        super(1000, 750, 1); 
    }

    public void addLeaves( int amount )
    {
    }

    public void increaseLeavesTo( int amount )
    {
    }
}
